import {MongoClient} from 'mongodb'

const uri = "mongodb://vareen:vareen@123@cluster0.llzni.mongodb.net/"; // Replace with your MongoDB URI
const dbName = "login"; // Replace with your database name

async function testConnection() {
    const client = new MongoClient(uri);
    try {
        await client.connect();
        console.log("✅ Connected successfully to MongoDB!");
        
        // Optional: List databases
        const databases = await client.db().admin().listDatabases();
        console.log("Databases:", databases);

    } catch (error) {
        console.error("❌ Connection failed:", error);
    } finally {
        await client.close();
    }
}

testConnection();
