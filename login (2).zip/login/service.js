const express = require('express');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const session = require('express-session');
const app = express();
const PORT = 5500;
const DATA_FILE = 'data.json';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'supersecretkey',
    resave: false,
    saveUninitialized: true
}));

// Load Data
function loadData() {
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], products: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8') || '{"users":[], "products":[]}');
}

let data = loadData();

// Save Data
function saveData() {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Register User
app.post('/register', async (req, res) => {
    const { username, email, password, confirm_password } = req.body;
    if (!username || !email || !password || !confirm_password) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    if (password !== confirm_password) {
        return res.status(400).json({ message: 'Passwords do not match' });
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = { id: crypto.randomUUID(), username, email, password: hashedPassword };
    data.users.push(user);
    saveData();

    res.status(201).json({ message: 'User registered successfully' });
});

// Login User
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = data.users.find(u => u.email === email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    req.session.user = user;
    res.json({ message: 'Login successful', username: user.username });
});

// Logout User
app.get('/logout', (req, res) => {
    req.session.destroy();
    res.json({ message: 'Logout successful' });
});

// Get Products
app.get('/products', (req, res) => {
    res.json(data.products);
});

// Get Account Info (Protected)
app.get('/account', (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Unauthorized' });
    }
    res.json({ message: `Welcome, ${req.session.user.username}!` });
});

// Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
