import express from "express";
import fs from "fs";
import bodyParser from "body-parser";
import cors from "cors";

const app = express();
const PORT = 8000;

// Middleware
app.use(cors()); // Allow cross-origin requests
app.use(bodyParser.json()); // Parse JSON request bodies

// API Endpoint to handle login
app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required!" });
    }

    // Create user object
    const userData = { username, password, timestamp: new Date() };

    // Read existing data from file (or initialize empty array if file doesn't exist)
    let users = [];
    try {
        const data = fs.readFileSync("data.json", "utf8");
        users = JSON.parse(data);
    } catch (error) {
        console.log("No existing data found, creating a new file.");
    }

    

    // Add new user data
    users.push(userData);

    // Save updated data to file
    fs.writeFileSync("data.json", JSON.stringify(users, null, 2));

    res.json({ message: "Login successful!", user: userData });
});

app.get("/api/datalelo" , (req, res) => {
    const data = fs.readFileSync("data.json" , "utf-8"); //stringified

    const jsonwaladata = JSON.parse(data);

    res.json({data : data , message : "Data Mil gaya " , status : 200})
})

// Start server
app.listen(PORT, () => {
    console.log(`✅ Server is running on http://localhost:${PORT}`);
});
